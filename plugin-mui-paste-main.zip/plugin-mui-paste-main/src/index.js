import * as FlexPlugin from '@twilio/flex-plugin';

import MuiPastePlugin from './MuiPastePlugin';

FlexPlugin.loadPlugin(MuiPastePlugin);
